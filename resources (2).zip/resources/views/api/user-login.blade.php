<?php 
echo json_encode_tr(u());
?>