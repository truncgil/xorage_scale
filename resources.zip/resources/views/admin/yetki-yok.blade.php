@extends('admin.master')
@section("title","Yetkiniz Yok")
@section("desc","Bu alanı görme yetkiniz yok")
@section('content')
<div class="content">
	<div class="block">
		<h1>Bu alanı görme yetkiniz yok</h1>
	</div>
</div>
	
@endsection
