/*
Translation from original CKEDITOR language files:
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("base64image","cs",{
	"alt":"Alternativní text",
	"lockRatio":"Zámek",
	"vSpace":"Vertikální mezera",
	"hSpace":"Horizontální mezera",
	"border":"Okraje"
});