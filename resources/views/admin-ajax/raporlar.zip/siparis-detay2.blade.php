<?php $stoklar = db("stoklar")->where("type",get("id"))
->whereNull("cikis") // çıkışı yapılmayan barkodlar listelensin yalnızca
->orderBy("id","DESC")->get();
 ?>
<div class="input-group">
    <select name="stok" class="stok-sec">
        <option value="">{{e2("SEÇİNİZ")}}</option>
        <?php foreach($stoklar AS $s) {
        ?>
        <option value="{{$s->id}}">{{$s->slug}} / {{$s->net}}</option>
        <?php 
    } ?>
    </select>
    <button class="btn btn-primary"><i class="fa fa-plus"></i></button>
</div>

     
<script>
    $(".stok-sec").select2();
    $(".stok-sec").on("change",function(){
        $(".info").html("Yükleniyor...").load("?ajax=print-stok&noprint&id="+$(this).val());
    });
</script>