<?php $sorgu = db("stok_cikislari")->where("siparis_id",get("id"))->get();

?>
<table class="table">
    <tr>
        <td>{{e2("BARKOD")}}</td>
        <td>{{e2("STOK BİLGİSİ")}}</td>
        <td>{{e2("MİKTAR")}}</td>
    </tr>
    <?php foreach($sorgu AS $s) { 
        $stok = j($s->stok);
        $stok_json = j($stok['json']);
      ?>
     <tr>
         <td>{{$stok['slug']}}</td>
         <td>{{urun_ozellikleri($stok_json)}}</td>
         <td>{{nf($s->qty)}}</td>
     </tr> 
     <?php } ?>
</table>