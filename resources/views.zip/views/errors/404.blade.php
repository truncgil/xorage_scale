@extends('errors::minimal')

@section('title', __('Sayfa Bulunamadı'))
@section('code', '404')
@section('message', __('Sayfa Bulunamadı'))
