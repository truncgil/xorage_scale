<?php use App\Contents; 
$title = "title";
$description = "desc";
$keywords = "keywords";

?>

@extends('layouts.app')

@section("title",$title)
@section("description",$description)
@section("keywords",$keywords)


@section('content')

<div class="block text-align-center">
    
</div>

@endsection

