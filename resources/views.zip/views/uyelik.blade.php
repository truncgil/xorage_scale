<?php use App\Contents; ?>

@extends('layouts.app')

@section("title","Sizi Tanıyalım")
 
    

@section('content')

    
@endsection

