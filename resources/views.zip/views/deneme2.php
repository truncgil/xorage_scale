<!-- Initial Page, "data-name" contains page name -->
<div data-name="deneme" class="page">

<!-- Top Navbar -->
<div class="navbar">
  <div class="navbar-bg"></div>
  <div class="navbar-inner">
    <div class="title">
        <img src="{{url("assets/icon.svg")}}" width="48" style="    width: 40px;
vertical-align: middle" alt="">
        Deneme
    </div>
  </div>
</div>

<!-- Bottom Toolbar -->
<div class="toolbar toolbar-bottom">
  <div class="toolbar-inner">
    <!-- Toolbar links -->
    <a href="#" class="link"><i class="f7-icons">phone</i></a>
    <a href="cihaz-bilgisi" class="link"><i class="f7-icons">wifi</i></a>
  </div>
</div>

<!-- Scrollable page content -->
<div class="page-content">
        asdad
</div>
</div>