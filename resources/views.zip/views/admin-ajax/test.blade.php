<?php 
oturumAc();
print_r($_SESSION);
 ?>assad