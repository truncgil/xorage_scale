<?php 
if(Auth::check()) {
	echo 1;
} else {
	echo 0;
}
 ?>